# Peer review - DBMS Assignment 1

Group reviewed: ____________________

Reviewer group: G9

## Comments

1. Section / page: ____________________

   Observation: ________________________________________________

   Suggested change: ___________________________________________

2. Section / page: ____________________

   Observation: ________________________________________________

   Suggested change: ___________________________________________

3. Section / page: ____________________

   Observation: ________________________________________________

   Suggested change: ___________________________________________

Use specific comments about research questions, evidence, method, results, citations, figures, or readability. Avoid general remarks such as “good work” or “improve the paper.”
